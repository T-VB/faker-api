//Since we in backend, imports are done by = require('@faker-js/faker')
const express = require("express");
const app = express();
const PORT = 8000;
const { faker } = require("@faker-js/faker");

//Middleware (processes data/piece meal before hitting server)
//app.use() function is middleware that gets run first before each req object gets ran
//takes POST data and adds it into the body field of the req object
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//following function will create a new user with these attributes(through faker with random data)
const createUser = () => {
  return {
    _id: faker.datatype.uuid(),
    first_name: faker.name.firstName(),
    last_name: faker.name.lastName(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    phone_number: faker.phone.number(),
  };
};

const createCompany = () => {
  return {
    _id: faker.datatype.uuid(),
    name: faker.name.fullName(),
    address: {
      street: faker.address.street(),
      city: faker.address.city(),
      state: faker.address.state(),
      zip: faker.address.zipCode(),
      country: faker.address.country(),
    },
  };
};

//app.listen - runs server
app.listen(PORT, () => {
  //`use backticks and ${}` for string interpolation
  console.log(`Server is up arunning on port ${PORT}`);
});

//Routing:
app.get("/user/new", (req, res) => {
  //console.log(req);
  console.log(req.url, req.method);
  const user = createUser(); //storing/creating 'user' as a variable
  res.json(user);
});

//Routing:
app.get("/companies/new", (req, res) => {
  const company = createCompany(); //storing/creating 'company' as a variable
  res.json(company);
});

//Routing to add user and company:
app.get("/user/company", (req, res) => {
  const newUser = createUser(); //storing/creating 'newUser' as a variable
  const newCompany = createCompany(); //storing/creating 'newCompany' as a variable
  const resObject = {
    user: newUser,
    company: newCompany,
  };
  res.json(resObject);
});

//Routing w/ adding a varible (:'word'):
//passing data through URL, in this case :word and getting added the "params" field in our req object
app.get("/word/:word", (req, res) => {
  res.json(req.params.word);
});

//POST request / Add a User:
app.post("/addUser", (req, res) => {
  console.log(req.body);
  console.log(req);
  res.json(req.body);
});
